
%Hlavni modul programu, ktery vse spousti a vola

parametry :- 	prenosny(L1), cpuVykon(L1, L2), gpuVykon(L2,L3), rozliseni(L3, L4), design(L4, L), 
		vypis(L), uvar(S,L), servis, write(S), nl,  
		name(S,L8), name('.dat',L9), conc(L8,L9,L0), name(S0,L0), servis, write(S0), nl, nl,
		ideal, hvezdy,		
		answer(S0), nl, 
		write('Prejete si nove zadani parametru? '), odpoved, read(V), hvezdy, nl, znovu(V).

%Blok textovych vypisu, kvuli opakovani predepsany

odpoved :- write('<odpovezte ano. nebo ne.>'). 

servis :- write('*servis data*: ').

hvezdy :- write('**** **** **** **** **** **** **** **** **** **** **** ****'), nl.

vytvarnoStart :- write('** Poradce pro vyber pocitace podle zakladnich parametru **'), nl.

ideal :- write('Idealni stroj pro Vas muze byt napriklad: '), nl. 


%Blok zadavani parametru pocitace

prenosny(Lnew) 		:- 	write('Melo by se jednat o laptop? '), odpoved, read(W), pridejData(10000, W, [], Lnew), nl. 

cpuVykon(Lold, Lnew)	:- 	write('Preferujete CPU vykon? (vysoky vykon vs. spotreba) ' ), odpoved, read(W), pridejData(1000, W, Lold, Lnew), nl. 
		
gpuVykon(Lold, Lnew)	:- 	write('Potrebujete vysoky GPU vykon? (hry, rendering) '), odpoved, read(W), pridejData(100, W, Lold, Lnew), nl. 
		
rozliseni(Lold, Lnew) 	:-  	write('Je pro Vas prioritou vysoke rozliseni displeje? '), odpoved, read(W), pridejData(10, W, Lold, Lnew), nl. 

design(Lold, Lnew)	:-	write('Davate prednost modernimu designu? '), odpoved, read(W), pridejData(1, W, Lold, Lnew), nl. 

%Predikat, ktery plni seznam daty, pokud je odpoved pozitivni

pridejData(Q,W,Lt,L) :- W == ano,
			pridej(Q, Lt, L), !.
pridejData(Q,W,Lt,L) :- pridej(0, Lt, L).

%Obecny predikat pro pridani prvku do seznamu

pridej(X, L, [X|L]). 

%Kontrolni predikat pro vypis seznamu

vypis([]).
vypis([H|T]) :- servis, write(H), nl, vypis(T).

%Z prvku seznamu naplnime promennou, ktera jednoznacne urcuje vybrany stroj

uvar(0,[]). 
uvar(M,[H|T]) :- uvar(M1,T), M is M1 + H.

%Obecny predikat pro spojeni seznamu, pouzit pro vytvoreni retezce jmena souboru z integerove promenne

conc([],L,L). 
conc([X|L1],L2,[X|L3]) :- conc(L1,L2,L3).

%Odpovedni predikat, ktery nalistuje adekvatni soubor a vypise jeho obsah do konzole

answer(F) :- see(F), nl, copy(65535,_) ~> FileString, seen, write(FileString), nl.

%Podminkovy predikat, ktery ovlivnuje cykleni programu, podle uzivatelovy odpovedi

znovu(V) :- 	V == ano,
		parametry, !.
znovu(V) :- 	fail.

%Spousteci predikat

run :- nl, hvezdy, vytvarnoStart, hvezdy, nl, parametry.  




